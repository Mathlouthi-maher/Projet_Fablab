#include<stdio.h> 
 
int main() 
{ 
  printf("On est dedant \n"); 
  return 0; 
}
