#include<stdio.h> 
//#include <stdbool.h>


int maxi3(int a, int b, int c)
{
  int max;

   
  if( (a>b) && (a>c))
    {
      
      max=a;
    }
  else if ((b>a) && (b>c))
      {
	max=b;

      }
  else
    {
      max=c;
      
    }
  return max;
  
}

int main () {
  int max;
  int a,b,c;
    printf("donne moi la valeur de a \n");
    scanf("%d",&a);
  printf("donne moi la valeur de b \n");
  scanf("%d",&b);
  printf("donne moi la valeur de c \n");
  scanf("%d",&c);
  max = maxi3(a,b,c);
  printf("%d c'est le maximum \n",max);
  
  return 0;
}

