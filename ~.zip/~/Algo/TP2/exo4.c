#include<stdio.h> 
#include <stdbool.h>


int maxi3(int a, int b, int c)
{
  int max;

   
  if( (a>b) && (a>c))
    {
      
      max=a;
    }
  else if ((b>a) && (b>c))
      {
	max=b;

      }
  else
    {
      max=c;
      
    }
  return max;
  
}
bool ordercroissant(int x,int y,int z)
{
  bool result;
  if( (x<y) && (y<z))
    {
      result=true;
    }
  else
    result =false;
  return result;
}
int main () {
  // int max;
  bool resultat;
  int a,b,c;
    printf("donne moi la valeur de a \n");
    scanf("%d",&a);
  printf("donne moi la valeur de b \n");
  scanf("%d",&b);
  printf("donne moi la valeur de c \n");
  scanf("%d",&c);
  //max = maxi3(a,b,c);
  resultat = ordercroissant(a,b,c);
  if (resultat == true)
    {
  printf("true\n");
    }
  else
    printf("false\n");
  return 0;
}

