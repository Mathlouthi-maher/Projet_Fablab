/* source du TP 3, module prog structurée, IMA3, 2013-2014 */
/* version originale de quizz.c Laure Gonnord pour IMA3, 2012 - 2013*/
/* d'après un TP d'Isabelle Sivignon, Grenoble 1, 2004*/

/*TP 3 : nom1 et nom2, date */

#include<stdio.h>
#include<stdbool.h>

/* nombre de questions - ne pas toucher*/
#define NB_QUES 6

/*-----------------------------*/
/**** Fonctions "questions" ****/
/*-----------------------------*/

/* Retourne true si et seulement si a<b<c */
/* Remarquer l'absence de IF */
bool ordre_croissant(int a, int b, int c)
{
  int res;
  res = (a<b && b<c); // true si a<b<c, false sinon.
  return res;
}

/* Retourne true si et seulement si a,b,c sont tous impairs */ 
bool tous_impairs(int a, int b, int c)
{
  int res;
  res = (a%2==1) && (b%2==1) && (c%2==1); // formule "tous impairs"
  return res;
}

/* Retourne true ssi a==b==c */  
bool egaux(int a, int b, int c)
{
  return ((a==b) && (b==c)); // directement !
}

/* Retourne true ssi a,b,c tous distincts */  
bool distincts(int a, int b, int c)
{
  return ((a!=b) && (b!=c) && (a!=c)); 
}

/* Retourne true ssi l'un est plus grand que la somme des 2 autres */
bool somme(int a, int b, int c)
{
  return ((a>=b+c) || (b>=c+a) || (c>=a+b));
}

/*Retourne true ssi les trois mesures sont celles d'un triangle rect*/
bool rectangle(int a, int b, int c)
{
  return((a*a==b*b+c*c) || (b*b==c*c+a*a) || (c*c==b*b+a*a));
} 

/*Fonction qui dispatche les questions suivant le numero*/
/* si i = 1, le résultat retourné est le résultat de ordre_croissant(x,y,z)*/
bool reponse_question(int i,int x,int y,int z)
{
  //à remplir

  return true;
}

/*-----------------------------*/
/****     Fonction main     ****/
/*-----------------------------*/

int main()
{
  /* Déclaration des variables */
  int a,b,c,rep,nbr_rep ;
  printf("Programme QUIZZ, bonjour!\n");
  
  /* Lecture des entiers */
  printf("donne moi la valeur de a \n");
  scanf("%d",&a);
  printf("donne moi la valeur de b \n");
  scanf("%d",&b);
  printf("donne moi la valeur de c \n");
  scanf("%d",&c);
  /* Gestion du questionnaire */
  printf("ces entiers sont ils dans l'ordre croissant \n");
  scanf("%d",&rep);
  if (rep == ordre_croissant(a,b,c))
    {
      printf("ta réponse est juste\n ");
	nbr_rep=nbr_rep+1;
    }
  else
    printf ("mauvaise reponse");
  /* Affichage du résultat */
  

  printf("Programme QUIZZ, au revoir!\n");
  return 0;
}
